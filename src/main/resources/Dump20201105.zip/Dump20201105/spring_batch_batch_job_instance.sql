CREATE DATABASE  IF NOT EXISTS `spring_batch` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `spring_batch`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: spring_batch
-- ------------------------------------------------------
-- Server version	5.7.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `batch_job_instance`
--

DROP TABLE IF EXISTS `batch_job_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch_job_instance` (
  `JOB_INSTANCE_ID` bigint(20) NOT NULL,
  `VERSION` bigint(20) DEFAULT NULL,
  `JOB_NAME` varchar(100) NOT NULL,
  `JOB_KEY` varchar(32) NOT NULL,
  PRIMARY KEY (`JOB_INSTANCE_ID`),
  UNIQUE KEY `JOB_INST_UN` (`JOB_NAME`,`JOB_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_instance`
--

LOCK TABLES `batch_job_instance` WRITE;
/*!40000 ALTER TABLE `batch_job_instance` DISABLE KEYS */;
INSERT INTO `batch_job_instance` VALUES (1,0,'basicJob','d41d8cd98f00b204e9800998ecf8427e'),(2,0,'systemCommandJob','d41d8cd98f00b204e9800998ecf8427e'),(3,0,'chunkBasedJob','d41d8cd98f00b204e9800998ecf8427e'),(4,0,'chunkBasedJob2','d41d8cd98f00b204e9800998ecf8427e'),(5,0,'chunkBasedJob1595342333423','853d3449e311f40366811cbefb3d93d7'),(6,0,'chunkBasedJob3','853d3449e311f40366811cbefb3d93d7'),(7,0,'chunkBasedJob1595342566572','853d3449e311f40366811cbefb3d93d7'),(8,0,'chunkBasedJob1595342774528','853d3449e311f40366811cbefb3d93d7'),(9,0,'conditionalJob','d41d8cd98f00b204e9800998ecf8427e'),(10,0,'conditionalJob1595344055657','d41d8cd98f00b204e9800998ecf8427e'),(11,0,'conditionalJob1595344062559','d41d8cd98f00b204e9800998ecf8427e'),(12,0,'conditionalJob1595344444279','d41d8cd98f00b204e9800998ecf8427e'),(13,0,'conditionalJob1595344461208','d41d8cd98f00b204e9800998ecf8427e'),(14,0,'conditionalJob1595344465900','d41d8cd98f00b204e9800998ecf8427e'),(15,0,'conditionalJob1595344471656','d41d8cd98f00b204e9800998ecf8427e'),(16,0,'conditionalJob1595344477785','d41d8cd98f00b204e9800998ecf8427e'),(17,0,'conditionalJob1595344510733','d41d8cd98f00b204e9800998ecf8427e'),(18,0,'conditionalJob1595344597625','d41d8cd98f00b204e9800998ecf8427e'),(19,0,'conditionalJob1595344605050','d41d8cd98f00b204e9800998ecf8427e'),(20,0,'conditionalStepLogicJob','d41d8cd98f00b204e9800998ecf8427e'),(21,0,'importCreditScoreJob','4aec073dac5ac03f99c18ca62a572e78'),(22,0,'importCreditScoreJob','9076a2d49b9873f9920ed91f49fba589'),(23,0,'importCreditScoreJob','3a5c897945276df240ee5ca33be6924a'),(24,0,'importCreditScoreJob','a181d3428ee049ef0e35784300fe5a3d'),(25,0,'importCreditScoreJob','1ebb36fc392f46b7f7dcdfcedc2cdce5'),(26,0,'importCreditScoreJob','0111949f02ce95257e234f4966764568'),(27,0,'importCreditScoreJob','27f199048d913e6d7466499c37cdf7d9'),(28,0,'importCreditScoreJob','e16e9014d2dd219fb04075addfde82b7');
/*!40000 ALTER TABLE `batch_job_instance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-05 22:34:59

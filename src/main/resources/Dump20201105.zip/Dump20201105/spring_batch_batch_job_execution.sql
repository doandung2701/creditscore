CREATE DATABASE  IF NOT EXISTS `spring_batch` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `spring_batch`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: spring_batch
-- ------------------------------------------------------
-- Server version	5.7.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `batch_job_execution`
--

DROP TABLE IF EXISTS `batch_job_execution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batch_job_execution` (
  `JOB_EXECUTION_ID` bigint(20) NOT NULL,
  `VERSION` bigint(20) DEFAULT NULL,
  `JOB_INSTANCE_ID` bigint(20) NOT NULL,
  `CREATE_TIME` datetime NOT NULL,
  `START_TIME` datetime DEFAULT NULL,
  `END_TIME` datetime DEFAULT NULL,
  `STATUS` varchar(10) DEFAULT NULL,
  `EXIT_CODE` varchar(2500) DEFAULT NULL,
  `EXIT_MESSAGE` varchar(2500) DEFAULT NULL,
  `LAST_UPDATED` datetime DEFAULT NULL,
  `JOB_CONFIGURATION_LOCATION` varchar(2500) DEFAULT NULL,
  PRIMARY KEY (`JOB_EXECUTION_ID`),
  KEY `JOB_INST_EXEC_FK` (`JOB_INSTANCE_ID`),
  CONSTRAINT `JOB_INST_EXEC_FK` FOREIGN KEY (`JOB_INSTANCE_ID`) REFERENCES `batch_job_instance` (`JOB_INSTANCE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_job_execution`
--

LOCK TABLES `batch_job_execution` WRITE;
/*!40000 ALTER TABLE `batch_job_execution` DISABLE KEYS */;
INSERT INTO `batch_job_execution` VALUES (1,2,1,'2020-07-20 22:40:52','2020-07-20 22:40:52','2020-07-20 22:40:52','COMPLETED','COMPLETED','','2020-07-20 22:40:52',NULL),(2,2,2,'2020-07-21 21:09:52','2020-07-21 21:09:53','2020-07-21 21:09:58','FAILED','FAILED','java.util.concurrent.ExecutionException: java.io.IOException: Cannot run program \"touch\" (in directory \"\\\"): CreateProcess error=2, The system cannot find the file specified\r\n	at java.util.concurrent.FutureTask.report(Unknown Source)\r\n	at java.util.concurrent.FutureTask.get(Unknown Source)\r\n	at org.springframework.batch.core.step.tasklet.SystemCommandTasklet.execute(SystemCommandTasklet.java:126)\r\n	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)\r\n	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)\r\n	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)\r\n	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)\r\n	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)\r\n	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)\r\n	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)\r\n	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)\r\n	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)\r\n	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)\r\n	at org.springframework.batch.core.job.SimpleStepHandler.handleStep(SimpleStepHandler.java:148)\r\n	at org.springframework.batch.core.job.AbstractJob.handleStep(AbstractJob.java:410)\r\n	at org.springframework.batch.core.job.SimpleJob.doExecute(SimpleJob.java:136)\r\n	at org.springframework.batch.core.job.AbstractJob.execute(AbstractJob.java:319)\r\n	at org.springframework.batch.core.launch.support.SimpleJobLauncher$1.run(SimpleJobLauncher.java:147)\r\n	at org.springframework.core.task.SyncTaskExecutor.execute(SyncTaskExecutor.java:50)\r\n	at org.springframework.batch.core.launch.support.SimpleJobLauncher.run(SimpleJobLauncher.java:140)\r\n	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n	at sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n	at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n	at java.lang.reflect.Method.invoke(Unknown Source)\r\n	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.','2020-07-21 21:09:58',NULL),(3,2,3,'2020-07-21 21:20:30','2020-07-21 21:20:30','2020-07-21 21:20:32','COMPLETED','COMPLETED','','2020-07-21 21:20:32',NULL),(4,2,3,'2020-07-21 21:28:18','2020-07-21 21:28:18','2020-07-21 21:28:18','COMPLETED','NOOP','All steps already completed or no steps configured for this job.','2020-07-21 21:28:18',NULL),(5,2,4,'2020-07-21 21:29:01','2020-07-21 21:29:01','2020-07-21 21:29:04','COMPLETED','COMPLETED','','2020-07-21 21:29:04',NULL),(6,2,3,'2020-07-21 21:37:48','2020-07-21 21:37:48','2020-07-21 21:37:48','COMPLETED','NOOP','All steps already completed or no steps configured for this job.','2020-07-21 21:37:48',NULL),(7,1,5,'2020-07-21 21:38:54','2020-07-21 21:38:54',NULL,'STARTED','UNKNOWN','','2020-07-21 21:38:54',NULL),(8,2,4,'2020-07-21 21:39:28','2020-07-21 21:39:28','2020-07-21 21:39:28','COMPLETED','NOOP','All steps already completed or no steps configured for this job.','2020-07-21 21:39:28',NULL),(9,2,6,'2020-07-21 21:39:36','2020-07-21 21:39:36','2020-07-21 21:40:27','COMPLETED','COMPLETED','','2020-07-21 21:40:27',NULL),(10,2,7,'2020-07-21 21:42:47','2020-07-21 21:42:47','2020-07-21 21:43:37','COMPLETED','COMPLETED','','2020-07-21 21:43:37',NULL),(11,2,8,'2020-07-21 21:46:15','2020-07-21 21:46:15','2020-07-21 21:47:05','COMPLETED','COMPLETED','','2020-07-21 21:47:05',NULL),(12,2,9,'2020-07-21 21:54:54','2020-07-21 21:54:54','2020-07-21 21:54:54','COMPLETED','COMPLETED','','2020-07-21 21:54:54',NULL),(13,2,9,'2020-07-21 22:07:17','2020-07-21 22:07:17','2020-07-21 22:07:17','COMPLETED','COMPLETED','','2020-07-21 22:07:17',NULL),(14,2,10,'2020-07-21 22:07:36','2020-07-21 22:07:36','2020-07-21 22:07:36','COMPLETED','COMPLETED','','2020-07-21 22:07:36',NULL),(15,2,11,'2020-07-21 22:07:43','2020-07-21 22:07:43','2020-07-21 22:07:43','COMPLETED','COMPLETED','','2020-07-21 22:07:43',NULL),(16,2,12,'2020-07-21 22:14:05','2020-07-21 22:14:05','2020-07-21 22:14:05','COMPLETED','COMPLETED','','2020-07-21 22:14:05',NULL),(17,2,13,'2020-07-21 22:14:22','2020-07-21 22:14:22','2020-07-21 22:14:22','COMPLETED','COMPLETED','','2020-07-21 22:14:22',NULL),(18,2,14,'2020-07-21 22:14:26','2020-07-21 22:14:26','2020-07-21 22:14:27','COMPLETED','COMPLETED','','2020-07-21 22:14:27',NULL),(19,2,15,'2020-07-21 22:14:32','2020-07-21 22:14:32','2020-07-21 22:14:32','COMPLETED','COMPLETED','','2020-07-21 22:14:32',NULL),(20,2,16,'2020-07-21 22:14:38','2020-07-21 22:14:38','2020-07-21 22:14:38','COMPLETED','COMPLETED','','2020-07-21 22:14:38',NULL),(21,2,17,'2020-07-21 22:15:11','2020-07-21 22:15:11','2020-07-21 22:15:11','FAILED','FAILED','','2020-07-21 22:15:11',NULL),(22,2,18,'2020-07-21 22:16:38','2020-07-21 22:16:38','2020-07-21 22:16:38','COMPLETED','COMPLETED','','2020-07-21 22:16:38',NULL),(23,2,19,'2020-07-21 22:16:46','2020-07-21 22:16:46','2020-07-21 22:16:46','COMPLETED','COMPLETED','','2020-07-21 22:16:46',NULL),(24,2,20,'2020-07-21 22:24:37','2020-07-21 22:24:37','2020-07-21 22:24:37','COMPLETED','COMPLETED','','2020-07-21 22:24:37',NULL),(25,2,21,'2020-11-05 15:14:00','2020-11-05 15:14:00','2020-11-05 15:14:00','FAILED','FAILED','','2020-11-05 15:14:00',NULL),(26,2,22,'2020-11-05 15:14:58','2020-11-05 15:14:58','2020-11-05 15:14:58','FAILED','FAILED','','2020-11-05 15:14:58',NULL),(27,2,23,'2020-11-05 15:16:05','2020-11-05 15:16:05','2020-11-05 15:16:06','FAILED','FAILED','','2020-11-05 15:16:06',NULL),(28,1,24,'2020-11-05 15:18:33','2020-11-05 15:18:33',NULL,'STARTED','UNKNOWN','','2020-11-05 15:18:33',NULL),(29,1,25,'2020-11-05 15:19:48','2020-11-05 15:19:48',NULL,'STARTED','UNKNOWN','','2020-11-05 15:19:48',NULL),(30,1,26,'2020-11-05 15:22:12','2020-11-05 15:22:12',NULL,'STARTED','UNKNOWN','','2020-11-05 15:22:12',NULL),(31,2,27,'2020-11-05 15:22:28','2020-11-05 15:22:28','2020-11-05 15:22:28','FAILED','FAILED','','2020-11-05 15:22:28',NULL),(32,1,28,'2020-11-05 15:28:11','2020-11-05 15:28:11',NULL,'STARTED','UNKNOWN','','2020-11-05 15:28:11',NULL);
/*!40000 ALTER TABLE `batch_job_execution` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-11-05 22:34:59
